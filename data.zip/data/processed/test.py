import numpy as np
from pathlib import Path
from semanticid_llm_rec.models.rqvae import RQVAE  
from semanticid_llm_rec.utils.config import ensure_dirs, load_config
from torchinfo import summary



cfg = load_config("config/server.yaml")
rq_cfg = cfg["rqvae"]
model = RQVAE(
        input_dim=int(rq_cfg["input_dim"]),
        hidden_dim=int(rq_cfg["hidden_dim"]),
        latent_dim=int(rq_cfg["latent_dim"]),
        codebook_num=int(rq_cfg["codebook_num"]),
        codebook_size=int(rq_cfg["codebook_size"]),
    )






summary(model, input_size=(2, 384))

