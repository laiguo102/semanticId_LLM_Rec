import numpy as np

emb = np.load("data/processed/item_embedding.npy")